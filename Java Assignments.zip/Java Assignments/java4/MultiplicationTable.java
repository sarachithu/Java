package com.maveric.java4;

public class MultiplicationTable {

	public static void main(String[] args) {
		
        int num = 5 ;
		
		int result = 0;

		for ( int i = 1;i<= 30 ; i ++)
		{
		result= num* i;
		
		System.out.println( num + " * " + i + " = " + result);
	    }
		
	
	 }
}

	