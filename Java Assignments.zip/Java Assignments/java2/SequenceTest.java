package com.maveric.java2;

public class SequenceTest {

	public static void main(String[] args) {
		
		int num = 3 ;
		
		int result;

		for ( int i = 1;i<= 20 ; i ++)
		{
		result= num* i;
		
		System.out.println( num + " * " + i + " = " + result);
	}
		
	}
}
