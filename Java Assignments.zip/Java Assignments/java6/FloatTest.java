package com.maveric.java6;

public class FloatTest {

	public static void main(String[] args) {
		
		double temp[] = new double[] {10.0,11.4, 4.5,-2.0, 3.6,-3.5 };

		double min = temp[0]; 
		double max = temp[0]; 

		for (int i = 1; i < temp.length; i++) 
		{
			if (temp[i] > max) 
			{
				max = temp[i];
			}
			if (temp[i] < min) 
			{
				min = temp[i];
			}
		}

		System.out.println("Maximum Number is: " + max);
		
		System.out.println("Minimum Number is : " + min);
	}


	}
