package com.maveric.java3;

public class EvenCheck {

	public static void main(String[] args) {
	
		int result=0;
		
		for(int i=0;i<=50;i++)
		{
		if(i%2==0)
		result=result+i;
		}
		
		System.out.println(result);

		if ( result % 2 == 0 )
		{
	    System.out.println("Result is Even");
		}
		
	    else
	    {
	    System.out.println("Result is Odd");
	    }
}
}