package com.maveric.java8;

public class RectanglePattern {

		static void printRectangle(int length, int width) 
			{ 
				for (int i = 0; i < length; i++) 
				{ 
					System.out.println(); 
					
					for (int j = 0; j < width; j++) 
					{ 
		 
					if (i == 0 || i == length-1 || j== 0 || j == width-1) 
							
					System.out.print("*"); 
						
					else System.out.print(" "); 
					} 
				} 
			} 
			
	
			public static void main(String args[]) 
			{ 
				int lenth = 10, width = 6; 
				printRectangle(lenth, width) ; 
			} 
}
