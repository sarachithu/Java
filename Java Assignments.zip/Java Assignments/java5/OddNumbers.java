package com.maveric.java5;

public class OddNumbers {

	public static void main(String[] args) {
		
int result=0;
		
		for(int i=0;i<=20;i++)
		{
		if(i%2!=0)
		result=result+i;
		}
		
		System.out.println("Sum of Odd Number: "+result);
	}

}
