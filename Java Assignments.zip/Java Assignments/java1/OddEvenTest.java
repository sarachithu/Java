package com.maveric.java1;

public class OddEvenTest {

	public static void main(String[] args) {
		
        int i;
        
        System.out.println("ODD Numbers: ");
		
		for (i=0; i<=30; i++)   
		{
		if(i%2 !=0)
		{
			System.out.println(i+ "");
		}
				
		}
		
		System.out.println("Even Numbers: ");
		
		for (i=0; i<=30; i++) 
		{
			
		if(i%2==0)  {
			
		System.out.println(i+ "");
		}
		}
	}

}
